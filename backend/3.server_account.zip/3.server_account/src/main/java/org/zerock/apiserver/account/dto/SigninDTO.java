package org.zerock.apiserver.account.dto;


import lombok.Data;

@Data
public class SigninDTO {

    private String username;
    private String password;

}
